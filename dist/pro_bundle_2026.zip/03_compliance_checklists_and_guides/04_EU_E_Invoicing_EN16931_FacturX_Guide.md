# 2026 EU B2B E-Invoicing (EN 16931 / Factur-X / UBL) Implementation Guide

## Executive Summary for Freelancers & SMBs

Starting in 2025-2026, the European Union's **ViDA (VAT in the Digital Age)** directive and national mandates across EU member states make structured electronic invoicing mandatory for B2B transactions:
- **Germany (Wachstumschancengesetz)**: Mandatory receipt of EN 16931 e-invoices from Jan 1, 2025; phased mandatory issuance for B2B from 2026-2028.
- **France (PPF / PDP)**: Mandatory receipt from Sept 2026, mandatory issuance across large, mid-cap, and SMBs phased through 2026-2027.
- **Poland (KSeF)**: Phased national B2B e-invoicing platform enforcement in 2026.
- **Belgium**: Mandatory B2B e-invoicing via Peppol starting Jan 1, 2026.
- **Italy (SDI)**: Fully in effect.

Traditional PDF invoices with no structured machine-readable payload will **no longer be compliant for B2B tax deductions**.

---

## 1. What is European Standard EN 16931?

EN 16931 defines a semantic data model for the core elements of an electronic invoice. It is expressed in two primary syntax bindings:
1. **UBL 2.1 (Universal Business Language)**: Pure XML (`urn:oasis:names:specification:ubl:schema:xsd:Invoice-2`), standardized across the **Peppol BIS Billing 3.0** cross-border network.
2. **UN/CEFACT CII (Cross Industry Invoice)**: Often embedded inside a PDF/A-3 as a hybrid invoice known as **Factur-X** (France) or **ZUGFeRD 2.2** (Germany).

---

## 2. Mandatory Business Terms (BT) Reference Table

| Business Term | Name | Format / Code | Example Value |
| :--- | :--- | :--- | :--- |
| **BT-1** | Invoice Identifier | Text, max 100 chars | `INV-2026-0042` |
| **BT-2** | Invoice Issue Date | YYYY-MM-DD | `2026-10-29` |
| **BT-3** | Invoice Type Code | UNTDID 1001 code | `380` (Commercial invoice), `381` (Credit note) |
| **BT-5** | Invoice Currency Code | ISO 4217 (3 alpha) | `EUR` |
| **BT-9** | Payment Due Date | YYYY-MM-DD | `2026-11-28` |
| **BT-24** | Specification Identifier | URN | `urn:cen.eu:en16931:2017#compliant#urn:fdc:peppol.eu:2017:poacc:billing:3.0` |
| **BT-27** | Seller Legal Name | Text | `Freelance Studio SARL` |
| **BT-31** | Seller VAT Identifier | Country code + number | `FR12345678901` |
| **BT-34** | Seller Electronic Address | Peppol EAS code : ID | `9957:FR12345678901` |
| **BT-44** | Buyer Legal Name | Text | `Acme Client B.V.` |
| **BT-48** | Buyer VAT Identifier | Country code + number | `NL854321098B01` |
| **BT-84** | Payment Means Code | UNTDID 4461 | `58` (SEPA credit transfer), `30` (Bank transfer) |
| **BT-84 / IBAN** | Payee Financial Account | IBAN | `FR7630006000011234567890189` |
| **BT-95** | Tax Category Code | UNTDID 5305 | `S` (Standard), `AE` (Reverse Charge Art. 196), `E` (Exempt) |
| **BT-106** | Sum of Invoice Lines | Decimal (2 digits) | `1200.00` |
| **BT-109** | Total Tax Amount | Decimal (2 digits) | `240.00` |
| **BT-112** | Total With Tax | Decimal (2 digits) | `1440.00` |
| **BT-115** | Amount Due For Payment | Decimal (2 digits) | `1440.00` |

---

## 3. Cross-Border EU B2B: Reverse Charge Rules (Article 196)

When billing a B2B client in another EU member state:
- You do NOT charge domestic VAT.
- Set VAT Rate to `0%`.
- Set Tax Category Code to `AE` (Reverse charge).
- Required Legal Clause on Invoice (BT-120):
  > *"VAT Reverse Charge: Supply of services taxable in the recipient's country under Article 196 of EU VAT Directive 2006/112/EC. Recipient is liable for VAT."*
- Both Seller and Buyer VAT IDs must be verified via the European Commission VIES database.

---

## 4. Peppol & Transmission Checklist

1. **Verify Buyer Peppol Endpoint**: Request the client's Peppol ID (e.g. `0106:NL123456789B01` or `0009:FR...`).
2. **Validate XML**: Use our interactive validator or the official Peppol Schematron engine.
3. **Route through an Access Point**: Send through an accredited Peppol Service Provider or free government portal (Chorus Pro in France, Bund.de in Germany).
