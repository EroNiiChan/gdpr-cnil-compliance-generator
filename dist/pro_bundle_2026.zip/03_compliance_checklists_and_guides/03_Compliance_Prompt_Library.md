# B2B Compliance & Red-Teaming Prompt Library

Use these structured prompts to audit client workflows and generate compliance documentation in minutes.

## Prompt 1: Annex III & Article 5 Risk Triage
```text
Act as an EU AI Act Compliance Auditor (Regulation 2024/1689). Review the following software feature description:
[DESCRIBE FEATURE, INPUT DATA, AND DECISION IMPACT]
1. Classify the system into Unacceptable (Art. 5), High-Risk (Annex III), Limited/Transparency Risk (Art. 50), or Minimal Risk.
2. Identify whether the operator is a Provider or Deployer under Art. 25.
3. Output a 5-point technical remediation list required before production launch in the EU.
```

## Prompt 2: PII & GDPR Leakage Pre-Flight Audit
```text
Review the following JSON payload / prompt template sent to an external LLM API:
[PASTE PAYLOAD STRUCTURE]
Identify any direct or indirect personal data fields under GDPR, recommend exact pseudonymization or masking rules before API transmission, and draft a 1-paragraph Data Processing Addendum (DPA) technical note for the client.
```

## Prompt 3: Hallucination Guardrail System Prompt Snippet
```text
SYSTEM GUARDRAIL: You must answer strictly using the provided reference context. If the context does not contain the factual answer, state "INSUFFICIENT_CONTEXT: Escalating to human review." Never fabricate citations, pricing, legal clauses, or policy guarantees.
```
