# 2026 EU AI Act Technical & Contractor Compliance Checklist

Use this checklist before shipping any AI-assisted automation, wrapper, RAG pipeline, or custom model to a European B2B client.

## Phase 1: Role & Risk Classification (Regulation EU 2024/1689)
- [ ] **Confirm Operator Role**: Document in the statement of work (SoW) whether you are an independent technical integrator and the Client is the official **Deployer** (Art. 3(4)).
- [ ] **Article 5 Prohibited Screening**: Verify the system does NOT perform social scoring, biometric scraping, emotion recognition in workplaces/schools, or deceptive manipulation.
- [ ] **Annex III High-Risk Check**: Confirm whether the workflow touches HR/CV screening, creditworthiness, education grading, or critical infrastructure.
- [ ] **Article 4 AI Literacy**: Log internal team/contractor competence and safe prompting guidelines.

## Phase 2: Article 50 Transparency & Technical Safeguards
- [ ] **User Disclosure**: Add clear UI notice informing end-users they are interacting with an AI system.
- [ ] **Synthetic Content Marking**: Ensure generated text/audio/images include metadata or disclosure where required.
- [ ] **Prompt Injection & Guardrails**: Validate untrusted user inputs and enforce output schema validation.
- [ ] **Fallback & Human-in-the-Loop (HITL)**: Ensure high-impact actions require explicit human approval before execution.

## Phase 3: GDPR & Sub-Processor Alignment
- [ ] **Zero Data Retention / EU Endpoints**: Configure LLM API providers (OpenAI EU, Anthropic, Mistral, Azure Sweden/Frankfurt) with zero training retention on client data.
- [ ] **PII Anonymization**: Strip or mask personal identifiers prior to external API calls.
