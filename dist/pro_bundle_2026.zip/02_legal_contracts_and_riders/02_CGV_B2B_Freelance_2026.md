# CONDITIONS GÉNÉRALES DE VENTE (CGV) B2B PRESTATIONS TECH — ÉDITION 2026

### ARTICLE 1 — CHAMP D'APPLICATION ET OPPOSABILITÉ
Les présentes Conditions Générales de Vente (CGV) régissent l'ensemble des prestations informatiques, développements logiciels et missions de conseil réalisées par [Nom / Raison Sociale du Prestataire] pour tout client professionnel. Toute commande implique l'acceptation pleine et entière des présentes CGV, nonobstant toute clause contraire issue des conditions d'achat du client.

---

### ARTICLE 2 — RÉSERVE DE PROPRIÉTÉ INTELLECTUELLE DU CODE SOURCE
**Le Prestataire conserve la propriété pleine, entière et exclusive de l'ensemble des codes sources, architectures, documentations, scripts et livrables créés jusqu'à parfait encaissement de la totalité des sommes facturées.** 
Le transfert des droits patrimoniaux de propriété intellectuelle est subordonné au paiement intégral de la prestation. À défaut de complet paiement, le Client s'interdit d'exploiter, compiler ou déployer en production les livrables remis.

---

### ARTICLE 3 — LIMITATION EXPRESSE DE RESPONSABILITÉ
Dans le cas où la responsabilité civile professionnelle du Prestataire viendrait à être judiciairement établie, le montant global de l'indemnisation due ne pourra en aucun cas excéder le montant net hors taxes effectivement perçu par le Prestataire au cours des trois (3) derniers mois de la mission concernée. Le Prestataire ne saurait être tenu pour responsable des dommages indirects, pertes de chiffre d'affaires ou corruptions de bases de données tiers.

---

### ARTICLE 4 — RECETTE DES LIVRABLES ET CONTESTATION
Le Client dispose d'un délai impératif de dix (10) jours ouvrés à compter de la mise à disposition d'un livrable ou d'un jalon technique pour notifier par écrit ses réserves motivées. À défaut de contestation écrite dans ce délai, le livrable est réputé définitivement accepté et validé sans réserve.

---

### ARTICLE 5 — CLAUSE ATTRIBUTIVE DE JURIDICTION
Tout litige relatif à l'interprétation ou à l'exécution des présentes relèvera de la compétence exclusive des Tribunaux du ressort du siège du Prestataire, nonobstant pluralité de défendeurs ou appel en garantie.
