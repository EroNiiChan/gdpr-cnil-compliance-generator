# ACCORD DE SOUS-TRAITANCE DONNÉES PERSONNELLES (RGPD ARTICLE 28) — ÉDITION FREELANCE TECH 2026

Dans le cadre de ses prestations techniques, le Prestataire peut être amené à manipuler, tester ou administrer des bases de données ou serveurs contenant des données à caractère personnel confiées par le Client (agissant en qualité de Responsable de Traitement).

---

### ARTICLE 1 — INSTRUCTIONS DOCUMENTÉES (ART. 28(3)(a))
Le Prestataire traite les données personnelles uniquement sur instruction documentée et écrite du Client, y compris en ce qui concerne les transferts de données en dehors de l'Union Européenne.

---

### ARTICLE 2 — CONFIDENTIALITÉ & HABILITATION (ART. 28(3)(b))
Le Prestataire garantit que toute personne autorisée à traiter les données sous sa supervision s'est engagée à respecter une obligation stricte de secret professionnel et de confidentialité.

---

### ARTICLE 3 — MESURES DE SÉCURITÉ TECHNIQUES (ART. 32 & ART. 28(3)(c))
Le Prestataire applique des mesures rigoureuses de sécurité informatique :
- Chiffrement des communications en transit (TLS 1.3 obligatoire) et chiffrement des supports locaux (FileVault / BitLocker AES-256) ;
- Authentification multifacteur (MFA) systématique pour l'accès aux consoles cloud et serveurs du Client ;
- Absence de stockage de données réelles de production sur des postes de développement locaux non chiffrés.

---

### ARTICLE 4 — NOTIFICATION DES VIOLATIONS DE DONNÉES (ART. 33 & ART. 28(3)(f))
En cas de détection d'un incident de sécurité ou d'une violation avérée de données personnelles, le Prestataire en informe le Client dans un délai maximum de **36 heures** après en avoir pris connaissance, en fournissant les éléments factuels disponibles.

---

### ARTICLE 5 — SORT DES DONNÉES À L'ISSUE DU CONTRAT (ART. 28(3)(g))
À l'expiration de la mission, le Prestataire procède, au choix du Client, à la suppression définitive ou à la restitution de l'ensemble des données personnelles et copies existantes.
