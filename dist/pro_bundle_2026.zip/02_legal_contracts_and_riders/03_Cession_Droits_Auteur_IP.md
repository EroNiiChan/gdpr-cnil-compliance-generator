# CLAUSE DE CESSION DE DROITS DE PROPRIÉTÉ INTELLECTUELLE & CODE SOURCE (AVENANT 2026)

### ARTICLE 1 — CESSION CONDITIONNELLE SOUS CONDITION SUSPENSIVE
Sous la **condition suspensive impérative du paiement intégral et définitif** des honoraires et frais convenus au Bon de Commande, le Prestataire cède au Client, à titre exclusif pour les seuls livrables spécifiquement commandés et réalisés sur mesure :
1. Le droit de reproduction et d'installation des livrables logiciels ;
2. Le droit de représentation et d'exploitation commerciale pour les besoins internes du Client ;
3. Le droit d'adaptation et de maintenance corrective ou évolutive.

---

### ARTICLE 2 — EXCLUSION DU SAVOIR-FAIRE & DES BRIQUES OPEN SOURCE
Sont expressément **exclus de la présente cession** :
- L'ensemble des bibliothèques, dépendances, modules et frameworks open source tiers soumis à leurs licences respectives (MIT, Apache 2.0, BSD, GPL, etc.) ;
- Les outils internes génériques, scripts utilitaires, prompts d'ingénierie et méthodologies préexistantes du Prestataire.
Le Prestataire conserve la liberté totale de réutiliser son savoir-faire générique et ses composants logiciels non spécifiques pour tout autre client ou projet.

---

### ARTICLE 3 — GARANTIE D'ÉVICTION
Le Prestataire garantit au Client qu'il est l'auteur légitime des codes sources originaux créés et que ses livrables ne constituent pas une contrefaçon de droits tiers.
