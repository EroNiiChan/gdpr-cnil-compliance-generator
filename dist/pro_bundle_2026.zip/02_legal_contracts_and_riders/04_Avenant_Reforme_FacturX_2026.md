# AVENANT CONTRACTUEL OBLIGATOIRE — RÉFORME DE LA FACTURATION ÉLECTRONIQUE FACTUR-X 2026

**VU :**
- L'ordonnance n° 2021-1190 du 15 septembre 2021 relative à la généralisation de la facturation électronique ;
- La norme européenne EN 16931 et le standard franco-allemand hybride Factur-X / ZUGFeRD ;
- L'obligation pour toutes les entreprises assujetties à la TVA en France d'être en mesure de recevoir les factures électroniques dès le 1er septembre 2026.

---

### ARTICLE 1 — FORME DES FACTURES ET FORMAT HYBRIDE NORMALISÉ
Les Parties conviennent expressément que l'ensemble des factures émises au titre de leurs relations commerciales sera transmis sous forme électronique conforme à la norme **EN 16931** (format hybride **PDF/A-3 intégrant un fichier de métadonnées XML** structuré Factur-X ou flux UBL).

---

### ARTICLE 2 — TRANSMISSION DES IDENTIFIANTS OBLIGATOIRES
Le Client s'engage à communiquer sans délai au Prestataire :
1. Son numéro d'identification unique **SIREN à 9 chiffres** ;
2. Le code service et le numéro d'engagement juridique le cas échéant ;
3. L'identifiant de sa Plateforme de Dématérialisation Partenaire (PDP) accréditée ou son rattachement au Portail Public de Facturation (PPF).

Toute facture rejetée pour défaut de transmission ou inexactitude des identifiants client n'emportera aucune interruption des délais de paiement contractuels.
