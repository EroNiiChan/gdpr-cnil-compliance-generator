# B2B Freelance & Agency AI Liability Addendum (2026 Template)

> **Usage Note**: Attach this schedule to your standard Master Services Agreement (MSA) or Statement of Work (SoW) when delivering AI integrations, automations, or LLM workflows.

---

### Schedule A: Artificial Intelligence Systems & Regulatory Allocation

1. **Regulatory Role Allocation (EU AI Act)**
   The Parties acknowledge that Contractor acts strictly as an independent technical implementation specialist. Client acts as the **Deployer** (as defined under Article 3(4) of Regulation (EU) 2024/1689) and Data Controller under GDPR. Client retains sole authority and responsibility for determining the lawful purpose, human oversight procedures, and production operation of the deliverables.

2. **Probabilistic Nature of Generative Models**
   Client acknowledges that Large Language Models (LLMs) and machine learning systems are probabilistic in nature and may generate inaccurate, incomplete, or unexpected outputs ("Hallucinations"). Contractor warrants that integration code will conform to agreed technical specifications, but makes no warranty that third-party foundation model outputs will be error-free.

3. **Human-in-the-Loop (HITL) Obligation**
   Client agrees to maintain qualified human review prior to relying on system outputs for legal, financial, medical, employment, or customer-binding decisions.

4. **Liability Cap & Indemnification**
   Contractor's aggregate liability arising out of or related to AI system outputs shall not exceed the total fees paid by Client to Contractor in the three (3) months preceding the claim. Client shall indemnify and hold Contractor harmless from third-party or regulatory claims arising from Client's modification of prompts, removal of safety guardrails, or deployment into Annex III High-Risk use cases without prior written conformity assessment.
