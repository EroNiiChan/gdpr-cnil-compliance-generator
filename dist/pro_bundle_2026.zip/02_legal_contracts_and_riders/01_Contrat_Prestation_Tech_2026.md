# CONTRAT DE PRESTATION DE SERVICES INFORMATIQUES (RÉGIE / FORFAIT) — ÉDITION 2026

**ENTRE LES SOUSSIGNÉS :**

1. **Le Client :** [Dénomination Sociale], [Forme Juridique], au capital de [Montant] €, immatriculée au RCS de [Ville] sous le numéro SIREN [Numéro SIREN], dont le siège social est situé [Adresse], représentée par [Nom et Fonction du Représentant].
   *Ci-après dénommé « le Client », d'une part,*

**ET :**

2. **Le Prestataire :** [Nom / Raison Sociale], [Statut : Entrepreneur Individuel / Micro-Entreprise / EURL / SASU], immatriculé(e) au RCS/RNE sous le numéro SIREN [Numéro SIREN], dont le siège / domicile professionnel est situé [Adresse],
   *Ci-après dénommé « le Prestataire », d'autre part.*

---

### ARTICLE 1 — OBJET DU CONTRAT ET INDÉPENDANCE PROFESSIONNELLE STRICTE
Le Prestataire s'engage à exécuter pour le Client les prestations de développement logiciel, architecture technique, audit ou conseil informatique décrites dans le Devis ou Bon de Commande annexé.

**Clause Anti-Requalification Salariale :** Les Parties reconnaissent et acceptent que le présent contrat est une convention de prestations de services conclue entre deux professionnels indépendants. Le Prestataire organise son activité en toute autonomie, détermine librement ses horaires et le lieu d'exécution de ses missions (télétravail autorisé sans limitation), et utilise son propre matériel informatique. Il n'existe aucun lien de subordination juridique entre le Prestataire et le Client.

---

### ARTICLE 2 — OBLIGATION DE MOYENS RENFORCÉE
Compte tenu de la haute technicité des environnements informatiques, de l'évolution des bibliothèques tierces et des aléas technologiques inhérents aux logiciels, les engagements souscrits par le Prestataire constituent exclusivement une **obligation de moyens renforcée**, et en aucun cas une obligation de résultat, sauf engagement chiffré exprès convenu dans un devis forfaitaire validé par écrit.

---

### ARTICLE 3 — MODALITÉS FINANCIÈRES, PÉNALITÉS DE RETARD & FACTUR-X
1. **Taux Journalier ou Forfait :** Les prestations sont facturées sur la base d'un Taux Journalier Moyen (TJM) de [Montant] € Hors Taxes (HT).
2. **Facturation Électronique Factur-X :** Conformément à l'ordonnance n° 2021-1190 et à la norme européenne EN 16931, les factures sont transmises sous format électronique structuré Factur-X / UBL. Le Client s'engage à fournir son SIREN valide dès la signature.
3. **Pénalités Légales :** Conformément à l'article L. 441-10 du Code de commerce, toute facture impayée à l'échéance portera intérêt de plein droit à un taux égal à trois (3) fois le taux d'intérêt légal, assorti d'une indemnité forfaitaire légale pour frais de recouvrement de **40,00 €**.

---

### ARTICLE 4 — CONFIDENTIALITÉ & DONNÉES PERSONNELLES (RGPD)
Les Parties s'engagent à préserver la stricte confidentialité des données et accès échangés. Si le Prestataire intervient sur des flux contenant des données à caractère personnel, l'Avenant RGPD Article 28 annexé au présent contrat s'applique de plein droit.

Fait à ___________________, le _______________ en deux (2) exemplaires originaux.

**Pour le Client :**                                  **Pour le Prestataire :**
[Signature & Cachet]                                [Signature]
