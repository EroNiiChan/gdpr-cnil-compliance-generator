# 🚀 Quickstart Guide — Ultimate 2026 EU Freelance Suite (Solo Edition)

Welcome to your complete 2026 European Freelance & Compliance Toolkit!
Everything is built following the **zero-dependency philosophy**: all web tools run locally in your browser with 0 external tracking, 0 installation steps, and 100% offline capability.

---

## 📦 What's Inside Your Bundle

### 1. `01_interactive_apps/` (Browser-ready, Open in Chrome, Edge, Safari, Firefox)
- **`01_eu_ai_act_auditor.html`**: Interactive EU AI Act risk triage tool, Article 50 disclosure helper, and freelance liability buffer calculator.
- **`02_gdpr_cnil_privacy_shield.html`**: 10-point CNIL cookie compliance auditor, fine calculator, DPA & Privacy Notice generator.
- **`03_cra_nis2_security_auditor.html`**: Cybersecurity readiness auditor for CRA (Regulation 2024/2847) and NIS2 Directive (2022/2555).
- **`04_simulateur_tjm_freelance_2026.html`**: French TJM, Tax & Social simulator (Micro-Entreprise vs EURL vs SASU + ARE + Factur-X scanner).
- **`05_facturx_invoice_template.html`**: Printable, compliant Factur-X invoice template with 2026 French & EU mandatory mentions.
- **`06_contrats_freelance_viewer.html`**: Interactive viewer for all 5 tech freelance contracts.

### 2. `02_legal_contracts_and_riders/` (Editable Markdown `.md` for Word, Notion, Docs)
- **`01_Contrat_Prestation_Tech_2026.md`**: French IT service agreement with anti-requalification & 40€ recovery fee clauses.
- **`02_CGV_B2B_Freelance_2026.md`**: B2B terms of sale with source code reservation of title & liability capping.
- **`03_Cession_Droits_Auteur_IP.md`**: Copyright transfer rider protecting your reusable tools and prompts.
- **`04_Avenant_Reforme_FacturX_2026.md`**: Mandatory 2026 e-invoicing contract rider.
- **`05_Accord_Sous_Traitance_RGPD_Article28.md`**: Solo developer GDPR Article 28 DPA.
- **`06_B2B_Contract_Indemnity_Rider_EU_AI_Act.md`**: Schedule A allocating client as AI "Deployer".

### 3. `03_compliance_checklists_and_guides/`
- Full checklists for EU AI Act, Article 50 disclosures, prompt libraries, Factur-X guide, and sample compliant UBL XML invoice.

---

## ⚡ How to Use in 60 Seconds
1. Double-click any `.html` file inside `01_interactive_apps/` to run it immediately in your browser.
2. Copy any contract from `02_legal_contracts_and_riders/` into your favorite editor, fill in bracketed details `[Company Name]`, and append to your client proposals!
